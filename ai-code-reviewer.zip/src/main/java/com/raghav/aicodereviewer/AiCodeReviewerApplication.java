package com.raghav.aicodereviewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiCodeReviewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiCodeReviewerApplication.class, args);
	}

}
