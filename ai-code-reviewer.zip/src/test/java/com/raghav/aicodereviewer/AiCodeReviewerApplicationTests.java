package com.raghav.aicodereviewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiCodeReviewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
